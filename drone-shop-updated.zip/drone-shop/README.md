# Drone Shop

Интернет-магазин запчастей для дронов на React + Tailwind CSS.

## 🚀 Быстрый запуск

```bash
npm install
npm start
```

## 🌍 Деплой на Vercel

1. Залей проект на GitHub
2. Импортируй его на [vercel.com](https://vercel.com)
3. Нажми **Deploy** — всё будет работать автоматически!

## 🛠 Использовано

- React
- Tailwind CSS
- lucide-react (иконки)
- Custom UI-компоненты